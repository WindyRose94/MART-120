// character//
var characterx = 150;
var charactery = 150;

//controls//
var w = 50;
var s = 50;
var a = 50;
var d = 50;

//obsticles//
var obsticlex = 200;
var obsticley = 50;
var obsticlexs = [];
var obsticleys = [];
var diameter = [];
var obsticlexspeed = [];
var obsticleyspeed = [];

//mouse//
var clickx;
var clicky;

function setup() {
  createCanvas(400, 400);
  for (var i = 0; i < 50; i++) {
    obsticlexs[i] = getRandomNumber (500);
    obsticleys[i] = getRandomNumber (500);
    diameter[i] = getRandomNumber (25);
    obsticlexspeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
    obsticleyspeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
  }
  createCharacter(150,150);
}

function draw() {
  background(220);
  borders (10);
  textSize(20);
  text(HERE, width - 25, height - 25)
  drawCharacter ();
  cMovement();
  //ememy//
  fill(13,145,14);
  for (var i = 0; i < obsticlexs.length; i++) {
    circle(obsticlexs[i], obsticleys[i], diameter[i]);
    obsticlexspeed[i] = Math.floor(math.random() * (Math.floor(Math.random() * 5)) + 1);
    obsticleyspeed[i] = Math.floor(math.random() * (Math.floor(Math.random() * 5)) + 1);
    obsticlexs += obsticlexspeed[i];
    obsticleys += obsticleyspeed[i];
    if (obsticlexs[i] > width) {
      obsticlexs[i] = 0;
    }
    if (obsticlexs[i] < 0){
      obsticlexs[i] = width;
    }
    if (obsticleys[i] > height) {
      obsticleys[i] = 0;
    }
    if (obsticleys[i] < 0){
      obsticleys[i] = height;
    }
  }
  if(characterx > width && charactery > width - 50){
    fill(0);
    stroke(6);
    textSize(50);
    text("Good Job!", width / 2 - 50, height / 2 - 50);
  }
  fill(40,0,0);
  circle(clickx, clicky, 25);
}
function cMovement(){
  if (keyIsDown(w)){
    charactery -= 10;
  }
  if (keyIsDown(s)){
    charactery += 10;
  }
  if (keyIsDown(a)){
    characterx -= 10;
    console.log("movement: " + characterx);
  }
  if (keyIsDown(d)){
    charaterx += 10;
  }
}
function createCharacter(x,y) {
  characterx = x;
  charactery = y;
}
function drawCharacter(){
  fill(23,40,123);
  circle(characterx,charactery,25);
}
function borders(thickness){
  rect(0,0,width,thickness);
  rect(0,0,thickness,width);
  rect(0, height-thickness, width, thickness);
  rect(width- thickness, 0, thickness, height - 50);
}
function mouseClicked(){
  clickx = mousex;
  clicky = mousey;
}
function getRandomNumber(number){
  return Math.floor(Math.random() * number) + 10;
}











