function setup() {
  createCanvas(400, 400);
}

var movement1 =2

var eye1x = 140;
var eye1y = 150;
var eye1diameter = 50;

var eye2x= 260;
var eye2y= 150;
var eye2diameter = 50;

var mouthx1=200;
var mouthx2=275;
var mouthy1=100; 
var mouthy2=50;

var size = 32;
var count = 0;
var sizeDirection = 2;
    
function draw() {
  background(220);
  //nose//
  triangle(175,225,200,175,225,225);
  circle(225,210,25);
  circle(175,210,25); 
  //glasses//
  ellipse(140,150,100,80);
  ellipse(260,150,100,80);
  rect(190,150,20,5);
  //eye1//
  circle(eye1x,eye1y, eye1diameter);
  //eye2//
  circle(eye2x,eye2y,eye2diameter);
  //mouth//
  ellipse(mouthx1,mouthx2,mouthy1,mouthy2);
  line(190,150,210,150);
  //eyebrows//
  line(100,100,185,100);
  line(300,100,210,80);
  //face//
  line(150,275,250,275);
  line(150,350,250,350);
  line(100,50,300,50);
  line(100,50,50,130);
  line(300,50,350,130);
  line(50,130,50,250);
  line(350,130,350,250);
  line(350,250,250,350);
  line(150,350,50,250);
  point(150,60);
  point(250,80);
  //text//
  textSize(size);
  text('Trinity G.',250,390);
  
    if(eye1x >= 115 || eye1x <= 165)
    {
       movement1 *= -1;
    }

  size+= sizeDirection;
    count++;
    if(count > 5)
    {
        sizeDirection *=-1;
        count = 0;
    }
  
  
    if(eye2y >= 235 || eye2y <= 285)
    {
       movement1 *= -1;
    }
    eye2y += movement;
  
}