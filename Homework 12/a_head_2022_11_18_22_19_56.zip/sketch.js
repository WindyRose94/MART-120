var x= 50;
var y= 50;
var diameter= 50;
var mousex = 0;
var mousey = 0;
var s = 83;
var w = 87;
var a = 65;
var d = 68;
function setup() {
  createCanvas(400, 400);
}

function drawcircle()
{
      circle(45,45,45);
}
{ controlCircle();
      ellipse(mousex, mousey, 15, 50);
}
 function controlCircle()
    {

      if (x >= 300) 
      {
        x = 50;
      }
      
      if (y >= 300) 
      {
        y = 50;
      }

      if (keyIsDown(s)) 
      {
        y += 10;
      } 
      else if (keyIsDown(w)) 
      {
        y -= 10;
      }

      if (keyIsDown(d)) 
      {
        x += 10;
      } 
      else if (keyIsDown(s)) 
      {
        x -= 10;
      }

      if (diameter < 200) 
      {
        diameter += 2;
      } 
      else if (diameter >= 200) 
      {
        diameter = 25;
      }
  function draw()
      {
  background(220);
  fill(255,235,42);
  circle(x,y,diameter);
 
  //player//
      function player()
      {
  fill(0,0,0);
  circle(250,250,40);
  line(250,270,250,350);
  line(250,350,300,400);
  line(250,350,200,400);
  line(200,300,300,300);
      }
  //outside//
  function wall()
      {
  rect(0,350,5,400);
  rect(0,0,5,200);
  rect(0,0,400,5);
  rect(395,0,5,400);
  rect(0,395,400,5);
    }
  //obsticals//
      function obsticals()
      {
  fill(60,0,60);
  rect(100,350,50,50);
  random(0,400)
  fill(100,40,50);
  triangle(375,400,325,400,349,350);
  random(0,400)
      }
      function drawcircle()
      {
        if (mouseIsDown)
          {
            function drawcircle
          }
      }

        function youwin()
  {
    text('You Win!', 45,45);
  }
    }
        
        
   