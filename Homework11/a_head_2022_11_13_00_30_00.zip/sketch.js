var x= 50;
var y= 50;
var diameter= 50;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill(255,235,42);
  circle(x,y,diameter);
  //player//
  fill(0,0,0);
  circle(250,250,40);
  line(250,270,250,350);
  line(250,350,300,400);
  line(250,350,200,400);
  line(200,300,300,300);
  //outside//
  rect(0,350,5,400);
  rect(0,0,5,200);
  rect(0,0,400,5);
  rect(395,0,5,400);
  rect(0,395,400,5);
  //obsticals//
  fill(60,0,60);
  rect(100,350,50,50);
  random(0,400)
  fill(100,40,50);
  triangle(375,400,325,400,349,350);
  random(0,400)
function keyPressed() 
{
  if (key == 'd') 
  {
    x+=15;
  } 
  else if (key == 'a') 
  {
    x-=15;
  }
}
   var mousex = 0;
   var mousey = 0;
  }
        if(function mouseClicked() 
    {  
      mousex = mouseX;
      mousey = mouseY;
    
    })
          
      { circle(30,30,30)}
    if(diameter <= 0)
        {
             text('Good job!', 10, 30)
        }
        else
        {
             text('Keep trying', 10, 30)
        }
         
        
        
        
   