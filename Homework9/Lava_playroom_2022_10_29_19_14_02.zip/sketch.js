function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  triangle(175,225,200,175,225,225);
  circle(225,210,25);
  circle(175,210,25); 
  ellipse(140,150,100,80);
  ellipse(260,150,100,80);
  rect(190,150,20,5);
  circle(140,150,50);
  circle(260,150,50);
  ellipse(200,275,100,50);
  line(190,150,210,150);
  line(100,100,185,100);
  line(300,100,210,80);
  line(150,275,250,275);
  line(150,350,250,350);
  line(100,50,300,50);
  line(100,50,50,130);
  line(300,50,350,130);
  line(50,130,50,250);
  line(350,130,350,250);
  line(350,250,250,350);
  line(150,350,50,250);
  point(150,60,);
  point(250,80);
  textSize(32);
  text('Trinity G.',250,390);
  
}